<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Unidad 3</title>
</head>
<body>
    <center>
        <h1>UNIDAD 3. DESARROLLO DE UNA INTERFAZ DE PROGRAMACION DE APLICACIONES (API)</h1>
        
        <a href="declaracion-variables-a.jsp">1. declaracion de variables A</a><br>
        <a href="declaracion-variables-b.jsp">2. declaracion de variables B</a><br>
        <a href="declaracion-variables-c.jsp">3. declaracion de variables C</a><br>
        <a href="String.jsp">4. Uso de String en JSP</a><br>
        <a href="Int.jsp">5. Uso de Int en JSP</a><br>
        <a href="Float.jsp">6. Uso de Float en JSP</a><br>
        <a href="Double.jsp">7. Uso de Double en JSP</a><br>
        <a href="datos-materia.jsp">8. Datos de Materia</a><br>
        <a href="suma.jsp">9. suma</a><br>
        <a href="resta.jsp">10. resta</a><br>
        <a href="multiplicacion.jsp">11. multiplicacion</a><br>
        <a href="if.jsp">12. If</a><br>
        <a href="ciclos.jsp">13. ciclos</a><br>
        <a href="nombre-pedir.jsp">14. pedir nombre</a><br>
        <a href="registro_universidad.jsp">15. registro universidad</a><br>
        <a href="examen-u3.jsp">16. Examen Unidad 3</a><br>
        <a href="../index.html">Regresar</a><br><br>
    </center>
</body>
</html>